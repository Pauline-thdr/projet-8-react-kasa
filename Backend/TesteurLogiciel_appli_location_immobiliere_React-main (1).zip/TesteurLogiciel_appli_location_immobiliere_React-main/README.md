# Kasa API

## Prerequisites
You need Docker to launch the app API or you can use service installing nodejs on your system and running in backend forlder the following commandes: `npm install` then `npm start`

## Launch Project

With Docker run command

`docker-compose up -d`

To stop project run
`docker-compose down`

